using System;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Exceptionless.Api.Tests")]