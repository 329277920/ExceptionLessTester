﻿using System;

namespace Exceptionless.Core.Models {
    public enum NotificationMode {
        None = 0,
        New = 1,
        All = 2
    }
}