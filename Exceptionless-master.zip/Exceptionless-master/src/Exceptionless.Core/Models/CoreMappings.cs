﻿using System;
using AutoMapper;

namespace Exceptionless.Core.Models {
    public class CoreMappings: Profile {}
}
