﻿using System;

namespace Exceptionless.Core.Models {
    public class SummaryData {
        public string TemplateKey { get; set; }
        public object Data { get; set; }
    }
}