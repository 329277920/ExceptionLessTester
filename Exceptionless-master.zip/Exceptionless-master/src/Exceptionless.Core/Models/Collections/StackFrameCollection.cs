﻿using System;
using System.Collections.ObjectModel;
using Exceptionless.Core.Models.Data;

namespace Exceptionless.Core.Models {
    public class StackFrameCollection : Collection<StackFrame> { }
}