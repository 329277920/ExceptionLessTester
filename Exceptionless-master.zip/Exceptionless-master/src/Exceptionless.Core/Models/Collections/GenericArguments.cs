﻿using System;
using System.Collections.ObjectModel;

namespace Exceptionless.Core.Models {
    public class GenericArguments : Collection<string> {}
}