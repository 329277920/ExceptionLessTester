﻿using System;

namespace Exceptionless.Api.Models {
    public class UpdateEvent {
        public string EmailAddress { get; set; }
        public string Description { get; set; }
    }
}
