﻿using System;

namespace Exceptionless.Api.Models {
    public class UpdateEmailAddressResult {
        public bool IsVerified { get; set; }
    }
}