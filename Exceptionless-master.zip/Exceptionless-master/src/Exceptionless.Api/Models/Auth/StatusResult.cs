﻿using System;

namespace Exceptionless.Api.Models {
    public class TokenResult {
        public string Token { get; set; }
    }
}