﻿using System;

namespace Exceptionless.Api.Models {
    public class UpdateToken {
        public string Notes { get; set; }
    }
}