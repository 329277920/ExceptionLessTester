﻿using System;

namespace Exceptionless.Api.Models {
    public class NewOrganization {
        public string Name { get; set; }
    }
}